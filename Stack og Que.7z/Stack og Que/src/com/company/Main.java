package com.company;

public class Main {

    public static void main(String[] args) {
	    StackClass<String> s = new StackClass<>();
        s.push("qwe");
        s.push("dasd");
        s.push(",sdm");
        //System.out.println(s.size());

        System.out.println(s);
        //System.out.println(s.peek());
        //System.out.println(s.isEmpty());

        Iterator iter = s.getIterator();

        String hej = (String)iter.next();
        String hej1 = (String)iter.next();
        String hej2 = (String)iter.next();

        System.out.println(hej);
        System.out.println(hej1);
        System.out.println(hej2);

    }
}
