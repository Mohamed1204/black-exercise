package com.company;

import static java.util.Arrays.copyOf;


/**
 * Created by mooz on 27-09-2016.
 */
public class StackClass<T> implements Container{
    private T[] data;
    private int sizee=0;

    public StackClass() { //O(N)
        this.data =(T[]) new Object[1];

    }

    public void push(T things){ //
        int i = 0;
        for(i = 0; i< data.length; i++){
            if (data[i] == null){
                break;
            }
        }
        data[i] = things;
        this.data = copyOf(data, data.length+1);
        this.sizee++;
    }

    public T pop(){
        T value = null;
        int i = 1;
        value = data[sizee - i];
        data[sizee - i] = null;
        sizee--;

        return (T) value;
    }

    public T peek(){
        return data[sizee-1];
    }

    public boolean isEmpty(){
        for (int i = 0; i < size(); i++) {
            if(!(data[i]== null)){
                return false;
            }
        }

        return true;
    }

    public int size(){
        return sizee;
    }

    @Override
    public String toString() {
        int i = 0;
        String toPrint = "[";
        while(i < data.length){
            if(!(data[i] == null)) {
                toPrint = toPrint +" "+ data[i] + ",";
            }
            i++;
        }
        toPrint = toPrint + "]";
        return toPrint;
    }

    @Override
    public Iterator getIterator() {
        return new ElementIterator();
    }

    private class ElementIterator implements Iterator{
        int index = 0;
        @Override
        public boolean hasNext() {
            if(index >= sizee) {
                return false;
            }
            return true;
        }

        @Override
        public Object next() {
            T Element = data[index];
            this.index++;
            return Element;
        }
    }
}
