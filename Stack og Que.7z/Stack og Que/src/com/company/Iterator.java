package com.company;

/**
 * Created by mooz on 15-11-2016.
 */
public interface Iterator {
    public boolean hasNext();
    public Object next();
}
