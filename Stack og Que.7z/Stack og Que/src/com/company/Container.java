package com.company;

/**
 * Created by mooz on 15-11-2016.
 */
public interface Container {
    public Iterator getIterator();
}
