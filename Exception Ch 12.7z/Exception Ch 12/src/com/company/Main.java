package com.company;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        //mismatchMethod();// opg 2
        //outOfBoundException(); //opg3
        //Loan loan = new Loan(10.5, 9, -1); // opg 4 kaster en exception når et tal er i negativ
        //outOfMemoryMethod(); // opg10


    }


    public static void mismatchMethod () { // Opg 2
        boolean Continue = true;
        Scanner input = new Scanner(System.in);
        System.out.println("Choose any two random number that is non negative to find the sum.");
        while (Continue) {
            try {
                System.out.println("Choose first number value: ");
                int a = input.nextInt();


                System.out.println("Choose second number value: ");
                int b = input.nextInt();


                int sum = a + b;
                System.out.println("the sum of the two number is " + sum);
                Continue = false;
            } catch (InputMismatchException ex) {
                System.out.println("Please type an integer value, NOT LETTERS!");
                input.nextLine();
            }
        }
    }

    public static void outOfBoundException(){ //opg 3
        Random random = new Random();
        int[] array = new int[100];
        for (int i = 0; i<100; i++){
            array[i] = random.nextInt(9);
        }
        Scanner input = new Scanner(System.in);
        System.out.println("Choose index of Array");
        try{
            int a = input.nextInt();
            System.out.println(array[a]);
        }catch (ArrayIndexOutOfBoundsException ex){
            System.out.println("index out of bound");
        }

    }

    public static void outOfMemoryMethod(){
        int[] ar = new int[100000000];
        ar = new int[ar.length*1000000000];
    }

}



