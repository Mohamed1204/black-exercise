package com.company;

import java.util.*;

import static java.util.Collections.checkedMap;
import static java.util.Collections.sort;
import static java.util.Collections.swap;

public class Main {

    public static void main(String[] args) {

        LinkedList<Integer> list1 = new LinkedList<>();
        LinkedList<Integer> list2 = new LinkedList<>();
        LinkedList<Integer> list3 = new LinkedList<>();

        for (int i = 1; i < 11; i++) {
            list1.add(i);
        }

        for (int i = 11; i < 24; i++) {
            list2.add(i);
        }

        //System.out.println(list1);
        //System.out.println(list2);
        //System.out.println(alternate(list1, list2));

        //removeEvenInRange(list2, 1, 7);
        //System.out.println(list2);

        list3.add(3);
        list3.add(3);
        list3.add(7);
        list3.add(1);
        list3.add(1);
        list3.add(9);
        list3.add(1);
        list3.add(14);
        list3.add(2);
        list3.add(2);
        list3.add(17);
        //System.out.println(list3);
        //partition(list3, 4);
        //System.out.println(list3);
        sortAndRemoveDuplicates(list3);
        System.out.println(list3);
        //System.out.println(countUnique(list3));



        Set<String> stooges = new TreeSet<String>();
        stooges.add("Larry");
        stooges.add("Moe");
        stooges.add("Curly");
        stooges.add("oe");
        stooges.add("Shemp");
        stooges.add("Moe");

        Set<String> set1 = new HashSet<String>();
        set1.add("hej");
        set1.add("mo");
        set1.add("kaj");
        set1.add("dre");
        set1.add("mig");
        removeOddLength(set1);


        Set<Integer> set2 = new HashSet<Integer>();
        set2.add(1);
        set2.add(3);
        set2.add(4);
        set2.add(5);
        set2.add(6);

        Set<Integer> set3 = new HashSet<Integer>();
        set3.add(1);
        set3.add(2);
        set3.add(4);
        set3.add(0);
        set3.add(6);


        Map<String, String> opgMaps = new HashMap<>();
        opgMaps.put("ghs", "dig2");
        opgMaps.put("gh", "dig3");
        opgMaps.put("ghs1", "dig1");
        opgMaps.put("ghs2", "dig");
        opgMaps.put("ghs3", "dig4");
        opgMaps.put("ghs4", "dig5");
        opgMaps.put("ghs5", "dig");
        opgMaps.put("ghs6", "d");
        //System.out.println(isUnique(opgMaps));

        Map<String, String> map12 = new TreeMap<>();
        map12.put("janet", "janet1");
        map12.put("jan", "mo");


        Map<String, String> map13 = new TreeMap<>();
        map13.put("42", "Marty");
        map13.put("81", "Sue");
        map13.put("17", "Ed");
        map13.put("31", "Dave");
        map13.put("56", "Ed");
        map13.put("3", "Marty");
        map13.put("29", "Ed");
        System.out.println(reverse(map13));

        //System.out.println(subMap(map12, map13));
        System.out.println(countUnique(list3));
        //System.out.println(maxOccurences(list3));


    }

    public static LinkedList<Integer> alternate(LinkedList<Integer> list1, LinkedList<Integer> list2) { //opg2
        LinkedList<Integer> list3 = new LinkedList<>();
        int i = 0;
        while (i < list1.size() || i < list2.size()) {
            if (i < list1.size()) {
                list3.add(list1.get(i));
            }
            if (i < list2.size()) {
                list3.add(list2.get(i));
            }
            i++;
        }
        return list3;
    }

    public static void removeEvenInRange(LinkedList<Integer> list1, int start, int end) { // Opg3
        int check = start;
        while (check<=end) {
            if ((list1.get(start) % 2) == 0) {
                list1.remove(start);
                check++;
            }
            else {
                start++;
                check++;
            }
        }
    }

    public static void partition(LinkedList<Integer> list1, int E) { // Opg4
        LinkedList<Integer> list2 = new LinkedList<>();
        for (int i = 0; i < list1.size(); i++) {
            if (list1.get(i) < E) {
                list2.add(list1.get(i));
            }
        }
        for (int i = 0; i < list1.size(); i++) {
            if (list1.get(i) > E) {
                list2.add(list1.get(i));
            }
        }
        list1.clear();
        list1.addAll(list2);
    }

    public static void sortAndRemoveDuplicates(LinkedList<Integer> list1){ // Opg 5
        Set<Integer>  numbers = new HashSet<>();
        for(int i = 0; i<list1.size(); i++){
            numbers.add(list1.get(i));
        }
        list1.clear();
        list1.addAll(numbers);
        sort(list1);
    }

    public static int countUnique(LinkedList<Integer> list1) { // Opg 6
        Set<Integer> numbers = new HashSet<>();
        for (int i = 0; i < list1.size(); i++) {
            numbers.add(list1.get(i));
        }
        return numbers.size();
    }

    public static int countCommon(LinkedList<Integer> list1, LinkedList<Integer> list2){ //Opg 7
        Set<Integer>  numbers1 = new HashSet<>();
        Set<Integer>  numbers2 = new HashSet<>();
        //Iterator<Integer> itr1 = numbers1.iterator();
        for(int i = 0; i<list1.size(); i++){
            numbers1.add(list1.get(i));
        }
        for(int i = 0; i<list2.size(); i++){
            numbers2.add(list2.get(i));
        }
        int magnitude = numbers1.size() + numbers2.size();
        numbers1.addAll(numbers2);
        int diffrence = numbers1.size();
    return (magnitude - diffrence);
    }



    public static int minLength(Set<String> set1){ //Opg 8
        Iterator<String> itr = set1.iterator();
        String Element = itr.next();
        String word = Element;
        while(itr.hasNext()){
            Element = itr.next();
            if(Element.length() < word.length() ){
            word = Element;
            }
        }
        return word.length();
    }

    public static boolean hasEven(Set<Integer> set1){ //Opg9
        Iterator<Integer> itr = set1.iterator();
        Integer Element = itr.next();
        Integer num = Element;
            while (itr.hasNext()){
                if(Element%2 == 0){
                    return true;
                }
            Element = itr.next();
            }
        return false;
    }

    public static void removeOddLength(Set<String> set1){ // Opg 10
        Iterator<String> itr = set1.iterator();
        while(itr.hasNext()) {
            String Element = itr.next();
            if (!(Element.length() % 2 == 0)) {
                itr.remove();
            }
        }
    }

    public static Set<Integer> symmetricSetDifference(Set<Integer> set1, Set<Integer> set2){ //OPg11
        Set<Integer> dif1 = new HashSet<Integer>();
        Set<Integer> dif2 = new HashSet<Integer>();

        dif1.addAll(set1);
        dif1.removeAll(set2);

        dif2.addAll(set2);
        dif2.removeAll(set1);

        dif1.addAll(dif2);

        return dif1;
    }


    public static boolean contains3(LinkedList<String> List){ //Opg 12
        Map<String, Integer> ssnMap = new HashMap<>();
        int i = 0;
        while(i < List.size()){
            String Element = List.get(i);
            ssnMap.put(Element, 0);
            i++;
            int x = 0;
            while(x < List.size()){
                String Element1 = List.get(x);
                x++;
                if(Element.equals(Element1)) {
                    ssnMap.put(Element, ssnMap.get(Element)+1);
                }
                if (ssnMap.get(Element)== 3){
                    return true;
                }
            }
        }
        return false;
    }


    public static boolean isUnique(Map<String, String> Mapp){ // Opg 13
        Iterator<String> itr = Mapp.values().iterator();
        while (itr.hasNext()){
            String Element = itr.next();
            int count = 0;
            Iterator<String> itr1 = Mapp.values().iterator();

            while (itr1.hasNext()){
                String Element1 = itr1.next();
                if (Element.equals(Element1)){
                    count++;
                }
                if (count > 1){
                    return false;
                }
            }
        }
        return true;
    }


    public static Map<String, Integer> intersect(Map<String, Integer> map1, Map<String, Integer> map2){ //Opg 14
        Map<String, Integer> map3 = new HashMap<>();
        Set<String> set1 = map1.keySet();
        Set<String> set2 = map2.keySet();
        Iterator<String> itr = set1.iterator();

            while(itr.hasNext()){
                String Element = itr.next();
                Iterator<String> itr1 = set2.iterator();
                while (itr1.hasNext()){
                    String Element1 = itr1.next();
                    if (Element.equals(Element1) && map1.get(Element).equals(map2.get(Element1))){
                        map3.put(Element, map1.get(Element));
                    }
                }
            }
        return map3;
    }


    public static int maxOccurences(List<Integer> list1){ //Opg 15
        Map<Integer, Integer> Map1 = new HashMap<>();
        for (int i = 0; i < list1.size(); i++) {
            int x = 0;
            for (int j = 0; j < list1.size(); j++) {
                if (list1.get(i)== list1.get(j)){
                    x++;
                }
            }
            Map1.put(list1.get(i), x);
        }
        Iterator<Integer> itr = Map1.values().iterator();
        int numb = itr.next();
        while (itr.hasNext()){
            int numb1 = itr.next();
            if(numb< numb1){
             numb = numb1;
            }
        }
        return numb;
    }



    public static boolean is1to1(Map<String, String> Map1){ //Opg 16 samme som opg 13
        boolean test = isUnique(Map1);
        return test;
    }



    public static boolean subMap(Map<String, String> Map1, Map<String, String> Map2){ //Opg 17
        Set<String> set1 = Map1.keySet();
        Iterator<String> itr1 = set1.iterator();
        Set<String> set2 = Map2.keySet();
        Iterator<String> itr2 = set2.iterator();
        int count = 0;
            while (itr1.hasNext()){
                String Element1 = itr1.next();
                while (itr2.hasNext()){
                    String Element2 = itr2.next();
                    if (Element1.equals(Element2) && Map1.get(Element1).equals(Map2.get(Element2))){
                        count += 1;
                        break;
                    }
                }
            }
        if (count==Map1.size()){
            return true;
        }
        else{
            return false;
        }
    }



    public static Map<String, String> reverse(Map<String, String> Map1){ //Opg 18
        Map<String, String> MapNew = new HashMap<>();
        Set<String> set1 = Map1.keySet();
        Iterator<String> itrV = Map1.values().iterator();
        Iterator<String> itrK = set1.iterator();
        while (itrV.hasNext()){
            String ElementK = itrK.next();
            String ElementV = itrV.next();
            if(MapNew.containsKey(ElementV)){
                MapNew.put(ElementV, MapNew.get(ElementV)+" "+ElementK);
            }
            else{
                MapNew.put(ElementV, ElementK);
                }
        }
        return MapNew;
    }



    public static int rarest(Map<String, Integer> Map1){  // OPg 19









        return 5;
    }

}