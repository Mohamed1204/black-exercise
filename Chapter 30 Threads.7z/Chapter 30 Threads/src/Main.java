package com.company;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

//import static sun.management.snmp.jvminstr.JvmThreadInstanceEntryImpl.ThreadStateMap.Byte0.runnable;

public class Main {
    private static sum account = new sum();

    public static void main(String[] args) throws InterruptedException {
         //write your code here
        ExecutorService executor = Executors.newCachedThreadPool();

        for (int i = 0; i < 1000; i++) {
            executor.execute(new addSum());
        }
        executor.shutdown();
        while(!executor.isTerminated()){
        }
        System.out.println(account.getSum());  //EN OPGAVE FRA BOGEN


    }

    public static class addSum implements Runnable { //EN OPGAVE FRA BOGEN
        public void run(){
            account.add(1);
        }
    }

    public static class sum { //EN OPGAVE FRA BOGEN
        private int sum = 0;
        public int getSum(){
            return sum;
        }
        public synchronized void add(int i){
            sum = sum + i;
        }
    }
}