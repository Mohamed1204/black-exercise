package com.company;

import java.util.Arrays;
import java.util.Comparator;

public class Main<T> {

    public static void main(String[] args) {
        Integer[] list = {5, 5, 6, 0, 5, 2, 9, 4};
        String[] list1 = {"ali", "mo", "ahmed"};


        bubblesort(list1, new LengthComparator());


        System.out.println(Arrays.toString(list1));
        //System.out.println(Arrays.toString(list));

    }

    public static <T extends Comparable<T>> void bubbleSort1(T[] list) {
        boolean needNextPass = true;

        for (int k = 1; k < list.length && needNextPass; k++) {
            // Array may be sorted and next pass not needed
            needNextPass = false;
            for (int i = 0; i < list.length - k; i++) {
                if (list[i].compareTo(list[i + 1]) > 0) {
                    // Swap list[i] with list[i + 1]
                    T temp = list[i];
                    list[i] = list[i + 1];
                    list[i + 1] = temp;

                    needNextPass = true; // Next pass still needed
                }
            }
        }
    }


    public static <E extends LengthComparator> void bubblesort(String[] list, LengthComparator comparator) {
        boolean needNextPass = true;

        for (int k = 1; k < list.length && needNextPass; k++) {
            // Array may be sorted and next pass not needed
            needNextPass = false;
            for (int i = 0; i < list.length - k; i++)
                if (comparator.compare(list[i], (list[i+1])) < 0) {
                    // Swap list[i] with list[i + 1]
                    String temp = list[i];
                    list[i] = list[i + 1];
                    list[i + 1] = temp;

                    needNextPass = true; // Next pass still needed
                }
        }

    }
        public static class LengthComparator implements Comparator<String> {
            public int compare(String s1, String s2) {

                return (s1.length() - s2.length());
            }
        }




    public static <T extends Comparable<T>> void quicksort(T[] array, int x, int y) {
        if (x < y) {
            int i = x, j = y;
            T c = array[(i + j) / 2];

            do {
                while (array[i].compareTo(c) < 0) i++;
                while (c.compareTo(array[j]) < 0) j--;

                if ( i <= j) {
                    T tmp = array[i];
                    array[i] = array[j];
                    array[j] = tmp;
                    i++;
                    j--;
                }

            } while (i <= j);
            quicksort(array, x, j);
            quicksort(array, i, y);
        }
    }

}
