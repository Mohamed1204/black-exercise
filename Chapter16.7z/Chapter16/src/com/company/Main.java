package com.company;

public class Main {

    public static void main(String[] args) {

        LinkedIntList linkedIntList1 = new LinkedIntList();
        LinkedIntList linkedIntList = new LinkedIntList();
        for (int i = 0; i <8 ; i++) {
            linkedIntList.add(i);
        }
        //System.out.println(linkedIntList);
        /*System.out.println(linkedIntList.isSorted());
        System.out.println(linkedIntList.lastIndexOf(7));
        linkedIntList.set(2, 7);
        System.out.println(linkedIntList.lastIndexOf(7));
        System.out.println(linkedIntList.isSorted());
        System.out.println(linkedIntList.max());*/

        linkedIntList1.add(1);
        linkedIntList1.add(1);
        linkedIntList1.add(1);
        linkedIntList1.add(1);
        linkedIntList1.add(2);
        linkedIntList1.add(2);
        linkedIntList1.add(5);
        linkedIntList1.add(8);


        //System.out.println(linkedIntList1.countDuplicates());

        LinkedIntList linkedIntList2 = new LinkedIntList();
        linkedIntList2.add(1);
        linkedIntList2.add(1);
        linkedIntList2.add(1);
        linkedIntList2.add(1);
        linkedIntList2.add(1);
        linkedIntList2.add(1);

        linkedIntList2.add(-3);
        linkedIntList2.add(4);
        linkedIntList2.add(-7);
        linkedIntList2.add(10);

        //System.out.println(linkedIntList2.hasTwoConsecutive());

        //linkedIntList2.deleteBack();
        //System.out.println(linkedIntList2);
        //linkedIntList.switchPairs();

        //System.out.println(linkedIntList);
        //linkedIntList2.removeAll(1);

        //System.out.println(linkedIntList1.notEquals(linkedIntList1));
        LinkedIntList linkedIntList3 = linkedIntList.removeEvens();
        System.out.println("orginlae "+linkedIntList);
        System.out.println("ny "+linkedIntList3);
    }
}
