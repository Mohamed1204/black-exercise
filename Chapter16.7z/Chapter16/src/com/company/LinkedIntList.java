package com.company;

import java.util.List;

/**
 * Created by mooz on 22-09-2016.
 */
// Class LinkedIntList can be used to store a list of integers.
public class LinkedIntList {

    private ListNode front; // first value in the list

    // post: constructs an empty list
    public LinkedIntList() {
        front = null;
    }

    // post: returns the current number of elements in the list
    public int size() {
        int count = 0;
        ListNode current = front;
        while (current != null) {
            current = current.next;
            count++;
        }
        return count;
    }

    // pre : 0 <= index < size()
    // post: returns the integer at the given index in the list
    public int get(int index) {
        return nodeAt(index).data;
    }

    // post: returns comma-separated, bracketed version of list
    public String toString() {
        if (front == null) {
            return "[]";
        } else {
        }
        String result = "[" + front.data;
        ListNode current = front.next;
        while (current != null) {
            result += ", " + current.data;
            current = current.next;
        }
        result += "]";
        return result;
    }

    // post: returns the position of the first occurrence of the
    // given value (-1 if not found)
    public int indexOf(int value) {
        int index = 0;
        ListNode current = front;
        while (current != null) {
            if (current.data == value) {
                return index;
            }
            index++;
            current = current.next;
        }
        return -1;
    }

    // post: appends the given value to the end of the list
    public void add(int value) {
        if (front == null) {
            front = new ListNode(value);
        } else {
            ListNode current = front;
            while (current.next != null) {
                current = current.next;
            }
            current.next = new ListNode(value);
        }
    }

    // pre: 0 <= index <= size()
    // post: inserts the given value at the given index
    public void add(int index, int value) {
        if (index == 0) {
            front = new ListNode(value, front);
        } else {
            ListNode current = nodeAt(index - 1);
            current.next = new ListNode(value, current.next);
        }
    }

    // pre : 0 <= index < size()
    // post: removes value at the given index
    public void remove(int index) {
        if (index == 0) {
            front = front.next;
        } else {
            ListNode current = nodeAt(index - 1);
            current.next = current.next.next;
        }
    }

    // pre : 0 <= i < size()
    // post: returns a reference to the node at the given index
    private ListNode nodeAt(int index) {
        ListNode current = front;
        for (int i = 0; i < index; i++) {
            current = current.next;

        }
        return current;
    }

    public void set(int index, int value) {
        ListNode current;
        if (index == 0) {
            current = front;
            current.data = value;
        } else {
            current = nodeAt(index - 1);
            current.next = new ListNode(value, current.next.next); // sætter den nye node på og linker den til gamle nodes
        }
    }


    public int max() { // finder størreste tal i listen og retunere det
        ListNode current = front;
        int number = front.data;
        while (current.next != null) {
            if (number < current.next.data) {
                number = current.next.data;
            }
            current = current.next;
        }
        return number;
    }


    public boolean isSorted() {
        ListNode current = front;
        while (current.next != null) {
            if (current.data > current.next.data) {
                return false;
            }
            current = current.next;
        }
        return true;
    }

    public int lastIndexOf(int value) {
        int index = -1;
        int i = 0;
        ListNode current = front;

        while (current.next != null) {
            if (current.data == value) {
                index = i;
            }
            i++;
            current = current.next;
        }
        return index;
    }


    public int countDuplicates() { //opg 5
        ListNode current = front;
        int count = 0;
        while (current.next != null) {
            if (current.data == current.next.data) {
                while (current.data == current.next.data) {
                    count++;
                    current = current.next;
                }
                count++;
            }
            if (current.next != null) { // for at fikse ullige antal elementer i listen og undgå exception fejl
                current = current.next;
            }
        }
        return count;
    }


    public boolean hasTwoConsecutive() { // opg 6
        ListNode current = front;
        while (current.next != null) {
            if (current.data + 1 == current.next.data) {
                return true;
            }
            current = current.next;
        }
        return false;
    }


    public int deleteBack() { // opg 7
        ListNode current = front;
        while (current.next.next != null) {
            current = current.next;
        }
        int deletedValue = current.next.data;
        current.next = null;

        return deletedValue;
    }


    public void switchPairs() { // opg 8
        ListNode current = front;
        while (current.next != null) {
            int temp1 = current.data;
            current.data = current.next.data;
            current.next.data = temp1;
            current = current.next;
            if (current.next != null) {
                current = current.next;
            }
        }
    }

    public void stutter() { //opg 9
        ListNode current = front;
        while (current != null) {
            int temp = current.data;
            current.next = new ListNode(temp, current.next);
            current = current.next.next;
        }
    }


    public void stretch(int n) { //opg 10
        ListNode current = front;
        while (current != null) {
            int temp = current.data;
            for (int i = 0; i <n-1; i++) {
                current.next = new ListNode(temp, current.next);
                current = current.next;
            }
            current = current.next;
        }

    }


    public void compress(){ //opg 11
        ListNode current = front;
            while (current.next != null){
                int value = current.data + current.next.data;
                current.data = value;
                current.next = current.next.next;
                current = current.next;
            }
    }


    public void split(){ //opg12
        ListNode current = front;
        int index = 0;

        while (current != null){
            if(current.data <0){
                front = new ListNode(current.data, front);
                ListNode listhelp = nodeAt(index);
                listhelp.next = listhelp.next.next;
            }
            current = current.next;
            index++;
        }

    }

    public void transferFrom(LinkedIntList list2){ //opg 13
        ListNode current = front;
        ListNode current2 = list2.nodeAt(0);
        current = nodeAt(size()-1);
        current.next = current2;
    }


    public void removeAll(int value){ //opg 14
        ListNode current = front;
        while (current.next != null){
            if(current.next.data == value){
                current.next = current.next.next;
            }else{
                current = current.next;
            }
        }
        if (front.data == value){
            front = front.next;
        }
    }

    public boolean notEquals(LinkedIntList list2){ //opg 15
        ListNode current = front;
        ListNode current2 = list2.front;
        if (size() != list2.size()){
            return true;
        }
        while (current != null){
            if (current.data != current2.data){
                return true;
            }
            current = current.next;
            current2 = current2.next;
        }
        return false;
    }



    public LinkedIntList removeEvens() { // opg 16  virker ikke 100%
        LinkedIntList list1 = new LinkedIntList();
        ListNode current = front;
        list1.front = current;
        ListNode current2 = list1.front;
        front = current.next;
        current = front;
        int index = 1;

        while (current!= null) {
            if (index % 2 == 0) {
                current2.next = current;
                current2 = current2.next;
                current = nodeAt(index-1);
                current.next = current.next.next;
            }
            current = current.next;
            index++;
        }


        return list1;
        }




        public void removeRange(int n1, int n2){ // opg 17
            if (n1 < 0 || n2 > size()) {
                throw new IllegalArgumentException();
            } else {
                int index1 = n1;
                ListNode current = front;
                if (n1 == 0) {
                    while (index1 <= n2) {
                        front = front.next;
                        index1++;
                    }
                } else {
                    while (index1 <= n2) {
                        ListNode node = nodeAt(n1 - 1);
                        node.next = node.next.next;
                        index1++;
                    }
                }
            }
        }

 }
