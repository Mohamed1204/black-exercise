package com.company;

/**
 * Created by mooz on 14-11-2016.
 */
public class SharedCounter extends Thread{ // viker ike helt
    public static fag tal = new fag();
    public void run(){
        for (int i = 0; i <10 ; i++) {
            tal.increment();
        }
    }

    public static class fag{
        public int num = 0;

        public int getNum() {
            return num;
        }

        private synchronized void increment(){
            num = num +1;
        }
    }

}



