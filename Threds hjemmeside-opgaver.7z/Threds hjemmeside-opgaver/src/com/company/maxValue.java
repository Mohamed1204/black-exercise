package com.company;

import java.util.Arrays;
import java.util.Random;


public class maxValue extends Thread{
    private int low;
    private int hi;
    private int[] arr;
    public int max = 0;


    public maxValue(int[] arr, int low, int hi) {
        this.arr = arr;
        this.low = low;
        this.hi = hi;
    }

    @Override
    public void run() {
        //Random r = new Random();
        for (int i = low; i <= hi ; i++) {
            if (arr[i] > max) {
                max = arr[i];
            }
        }
    }
}
