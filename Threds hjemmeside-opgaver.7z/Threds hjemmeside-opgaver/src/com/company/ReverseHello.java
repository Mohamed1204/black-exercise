package com.company;

/**
 * Created by mooz on 14-11-2016.
 */

public class ReverseHello extends Thread { // mangler at printe dem omvendt

    private int counter;

    public ReverseHello(int counter) {
        this.counter = counter;
    }



    @Override
    public void run() {

            if (counter <= 50) {
                counter++;
                ReverseHello newThread = new ReverseHello(counter);
                System.out.println("hello " + counter);
                newThread.start();

            }

        }
    }



