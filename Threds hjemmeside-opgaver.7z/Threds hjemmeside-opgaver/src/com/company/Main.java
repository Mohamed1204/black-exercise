package com.company;

import sun.security.provider.SHA;

import java.util.Arrays;
import java.util.Random;

public class Main {

    public static void main(String[] args) throws InterruptedException {
/*        int[] number = new int[101];
        Random r = new Random();
        for (int i = 0; i < 101; i++) {
            number[i] = r.nextInt(100);
        }

        maxValue[] maxThreads = new maxValue[4];
        for (int b = 0; b < 4; b++) {
            maxThreads[b] = new maxValue(number, (b*25), ((b+1)*25));
            maxThreads[b].start();
        }

        int biggest = 0;
        for (int i = 0; i <4 ; i++) {
            maxThreads[i].join();
            if (biggest < maxThreads[i].max){
                biggest = maxThreads[i].max;
            }
        }

        //System.out.println(Arrays.toString(number));
        System.out.println("biggest number in the array is: "+biggest);
        */



/*ReverseHello hello = new ReverseHello(0);
        hello.start();*/

        SharedCounter.fag hej = new SharedCounter.fag();

        SharedCounter[] arrayThreads = new SharedCounter[10];
        for (int i = 0; i <10 ; i++) {
            arrayThreads[i] = new SharedCounter();
            arrayThreads[i].start();
        }
        System.out.println(hej.getNum()); // virker ikke helt skal give 100, tror shared-counter Class
                                          // skal laves alene med en main
                                        // skal måske implents istedet for extend ligesom i bog-opgaven




    }
}
