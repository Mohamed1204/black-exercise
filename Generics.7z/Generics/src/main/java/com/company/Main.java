package com.company;



public class Main {

    public static void main(String[] args) {
        ArrayListClass<Integer> AList = new ArrayListClass<Integer>(2);
        AList.add(5);
        AList.add(6);
        AList.add(4);
        AList.add(45);


        System.out.println(AList);
        System.out.println(AList.getData(2));
    }
}
