package com.company;


import static java.util.Arrays.copyOf;

/**
 * Created by mooz on 13-09-2016.
 */
public class ArrayListClass<T> {
    private T[] data;
    int size = 0;
    int capacitet;

    public ArrayListClass(int magnitude) { //O(1)
        this.data =(T[]) new Object[magnitude];

    }


    public void add(T things){ // O(N^2)
        int i = 0;
        for(i = 0; i< data.length; i++){
            if (data[i] == null){
             break;
            }
        }
        data[i] = things;
        this.data = copyOf(data, data.length+1);
        this.size++;
    }

    public void setData(T data, int index){ //O(1)

        this.data[index] = data;
    }

    public int getSize() { //O(1)

        return size;
    }


    public T getData(int index) { //O(1)

        return (T) data[index];
    }

    public String toString(){ // O(N)
        int i = 0;
        String toPrint = "";
        while(i < data.length){
            toPrint = toPrint + data[i]+" ";
            i++;
        }
        return toPrint;
    }
}


