package com.company;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by mooz on 14-11-2016.
 */
public class ArrayListClassTest {
    @Before
    public void setUp() throws Exception {

    }

    @Test
    public void add() throws Exception {
        ArrayListClass<String> listClass = new ArrayListClass<String>(10);
        listClass.add("trst");

        assertNotNull(listClass);
        assertEquals("trst", listClass.getData(0));
        assertEquals(1, listClass.getSize());

    }

    @Test
    public void setData() throws Exception {

    }

    @Test
    public void getSize() throws Exception {

    }

    @Test
    public void getData() throws Exception {
        ArrayListClass<String> listClass = new ArrayListClass<String>(10);
        listClass.add("mo");
        assertEquals("mo", listClass.getData(0));

    }

}