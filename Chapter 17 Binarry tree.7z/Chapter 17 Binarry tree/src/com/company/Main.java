package com.company;

public class Main {

    public static void main(String[] args) {


        IntTree tree = new IntTree(4);
        IntTree tree2 = new IntTree(5);

        tree.printSideways();
        //System.out.println(tree.countLeftNodes());
        //tree.printLevel(5);
        //tree.printLeaves();
        //System.out.println(tree.isFull());
        tree.doublePositive();
        tree.printSideways();
        System.out.println(tree.equals1(tree2.getOverallRoot()));

    }
}
