package com.company;

import java.util.*;

public class IntTree {
    private IntTreeNode overallRoot;

    // pre : max > 0
    // post: constructs a sequential tree with given number of
    //       nodes
    public IntTree(int max) {
        if (max <= 0) {
            throw new IllegalArgumentException("max: " + max);
        }
        overallRoot = buildTree(1, max);
    }

    // post: returns a sequential tree with n as its root unless
    //       n is greater than max, in which case it returns an
    //       empty tree
    private IntTreeNode buildTree(int n, int max) {
        if (n > max) {
            return null;
        } else {
            return new IntTreeNode(n, buildTree(2 * n, max),
                    buildTree(2 * n + 1, max));
        }
    }

    // post: prints the tree contents using a preorder traversal
    public void printPreorder() {
        System.out.print("preorder:");
        printPreorder(overallRoot);
        System.out.println();
    }

    // post: prints the tree contents using a preorder traversal
    // post: prints in preorder the tree with given root
    private void printPreorder(IntTreeNode root) {
        if (root != null) {
            System.out.print(" " + root.data);
            printPreorder(root.left);
            printPreorder(root.right);
        }
    }

    public IntTreeNode getOverallRoot() {
        return overallRoot;
    }

    // post: prints the tree contents using a inorder traversal
    public void printInorder() {
        System.out.print("inorder:");
        printInorder(overallRoot);
        System.out.println();
    }

    // post: prints in inorder the tree with given root
    private void printInorder(IntTreeNode root) {
        if (root != null) {
            printInorder(root.left);
            System.out.print(" " + root.data);
            printInorder(root.right);
        }
    }

    // post: prints the tree contents using a postorder traversal
    public void printPostorder() {
        System.out.print("postorder:");
        printPostorder(overallRoot);
        System.out.println();
    }

    // post: prints in postorder the tree with given root
    private void printPostorder(IntTreeNode root) {
        if (root != null) {
            printPostorder(root.left);
            printPostorder(root.right);
            System.out.print(" " + root.data);
        }
    }

    // post: prints the tree contents, one per line, following an
    //       inorder traversal and using indentation to indicate
    //       node depth; prints right to left so that it looks
    //       correct when the output is rotated.
    public void printSideways() {
        printSideways(overallRoot, 0);
    }

    // post: prints in reversed preorder the tree with given
    //       root, indenting each line to the given level
    private void printSideways(IntTreeNode root, int level) {
        if (root != null) {
            printSideways(root.right, level + 1);
            for (int i = 0; i < level; i++) {
                System.out.print("    ");
            }
            System.out.println(root.data);
            printSideways(root.left, level + 1);
        }
    }

    public int countLeftNodes() { // opg1
        int count = countLeftNodes(overallRoot);
        return count;
    }

    public int countLeftNodes(IntTreeNode root) { // opg1
        int count = 0;
        if (root.left != null) {
            count =count + 1 + countLeftNodes(root.left);
        }
        if (root.right != null) {
            count = count + countLeftNodes(root.right);
        }
        return count;
    }

    public int countEmpty() { // opg 2
        int count = countEmpty(overallRoot);
        return count;
    }

    private int countEmpty(IntTreeNode root) { // opg 2
        int count = 0;
        if (root.left != null) {
            count = count + countEmpty(root.left);
        } else {
            count = count + 1;
        }


        if (root.right != null) {
            countEmpty(root.right);
            count = count + countEmpty(root.right);
        } else {
            count = count + 1;
        }
        return count;
    }


    public int dephtSum() { //opg 3
        int sum = dephtSum(overallRoot, 1);

        return sum;
    }

    private int dephtSum(IntTreeNode root, int level) { // opg3

        int sum = 0;
        if (root.left != null) {
            sum = sum + dephtSum(root.left, level + 1);
        }

        if (root.right != null) {
            sum = sum +  dephtSum(root.right, level + 1);
        }

        sum = level*root.data + sum;

        return sum;
    }


    public int countEvenBranches(){ // opg 4
        int count = countEvenBranches(overallRoot);
        return count;
    }

    private int countEvenBranches(IntTreeNode root){ // opg 4
        int count = 0;
        if(root.left != null){
           count = count + countEvenBranches(root.left);
        }
        if (root.right != null){
            count = count + countEvenBranches(root.right);
        }

        if ((root.left != null || root.right != null) && root.data % 2 == 0){
            count++;
        }
        return count;
    }



    public void printLevel(int n){ // opg 5
        printLevel(overallRoot, 1, n);
    }

    private void printLevel(IntTreeNode root, int level, int n){ // opg 5

        if(root.left != null){
            printLevel(root.left, level+1, n);
        }

        if (root.right != null){
            printLevel(root.right, level+1, n);
        }
        if (n == level){
            System.out.println(root.data);
        }
    }



    public void printLeaves(){ // opg 6
        printLeaves(overallRoot);
    }

    private void printLeaves(IntTreeNode root){ // opg 6
        if(root.right != null){
            printLeaves(root.right);
        }

        if (root.left != null){
            printLeaves(root.left);
        }

        if (root==null){
            System.out.println("no leaves to print"); // viker ikke pga construteren ikke tillader at oprette en tom tree
        }
        else if (root.left == null && root.right == null){
            System.out.println(root.data);
        }
    }



    public boolean isFull(){ // opg 7
        return isFull(overallRoot);
    }

    private boolean isFull(IntTreeNode root){ // opg 7
        boolean test = true;

        if(root.right != null){
            test = isFull(root.right);
        }

        if (root.left != null){
            test = isFull(root.left);
        }


        if ((root.left != null && root.right == null) || (root.left == null && root.right != null)){
            test = false;
        }
        return test;
        }


    //    opg 9
    public boolean equals1(IntTreeNode t2) {
        return equals1(overallRoot, t2);
    }

    private boolean equals1(IntTreeNode root, IntTreeNode tree) {
        if (root == null && tree == null){
            return true;

        } else if (root != null && tree != null){
            return root.data == tree.data &&
                    equals1(root.left, tree.left) &&
                    equals1(root.right, tree.right);

        } else{
            return false;
        }
    }





        public void doublePositive(){ // opg 10
            doublePositive(overallRoot);
        }

        private void doublePositive(IntTreeNode root){ // opg 10
            if (root.right != null){
                doublePositive(root.right);
            }

            if (root.left != null){
                doublePositive(root.left);
            }
            root.data = root.data *2;
        }


}
