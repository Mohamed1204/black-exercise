package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        // write your code here
        //ændre på Graph1.txt og Graph2.txt for output
        Scanner input = new Scanner(new File("Graph2.txt"));
        String numOfV = "";
        int index = 0;
        int y = 0;
        int x = 0;
        String[] vertices = null;
        ArrayList<AbstractGraph.Edge> edges = new ArrayList<>();
        while (input.hasNext()) {
            String s = input.nextLine();
            String[] a = s.split("[\\s+]");
            for (int i = 0; i < a.length; i++) {
                if (a.length == 1) {
                    numOfV = a[i];
                    vertices = new String[Integer.parseInt(numOfV)];
                } else if (!(a.length == 1)){
                    if (i == 0) {
                        vertices[index] = a[i];
                        index++;
                    } else {
                        x = Integer.parseInt(a[0]);
                        y = Integer.parseInt(a[i]);
                        edges.add(new AbstractGraph.Edge(x, y));
                    }
                }
            }
        }
        Graph<String> graph = new UnweightedGraph<>(Arrays.asList(vertices),edges);
        System.out.println("The number of vertices is " + graph.getSize());
        graph.printEdges();
    }
}

