package com.company;


import java.util.Arrays;

public class Main {

    public static void main(String[] args) {
	    HashIntSet mainSet = new HashIntSet();
        mainSet.add(1);
        mainSet.add(3);
        mainSet.add(6);
        mainSet.add(8);
        mainSet.add(10);

        HashIntSet set2 = new HashIntSet();
        set2.add(1);
        set2.add(3);
        set2.add(4);
        set2.add(6);
        set2.add(0);

        //mainSet.addAll(set2);
        //System.out.println(mainSet);
        //mainSet.removeAll(set2);
        //System.out.println(mainSet);
        mainSet.retainAll(set2);
        System.out.println(mainSet);
        System.out.println(Arrays.toString(mainSet.toArray()));

    }
}
